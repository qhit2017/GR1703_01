
public class zy2 {
	
	public static void main(String[] args) {
		
		Dog a = new Dog();
		
		a.setName("ëë");
		a.setColor("��ɫ");
		a.setPinzhong("�ǹ�");
		a.setZhongliang(101);
		a.setAge(40);
		
		a.jiao();
		
	}

}
