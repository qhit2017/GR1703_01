package wrt;

import java.awt.Color;

public class dog {

	private String name;
	private String pinzhong;
	private String  colour;
	private int age;
	private int weight;
	public String jaio;
	public String chi;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPinzhong() {
		return pinzhong;
	}
	public void setPinzhong(String pinzhong) {
		this.pinzhong = pinzhong;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		if(colour==colour){
			System.out.println("�ǲ�������");
			
		this.colour = colour;
		}
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		if(age>30){
			System.out.println("̫����");
			this.age = age;
		}
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		if (weight>100){
			System.out.println("̫����");
			this.weight = weight;
		}
	}
	public String sleep;
	public void dog(){
		System.out.println("����"+name+""+pinzhong+"��"+",ë����ɫ��"+colour+",��������"+age+"�꣬��������"+"weight");
	}
}
